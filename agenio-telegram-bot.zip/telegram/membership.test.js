import assert from "node:assert/strict";
import test from "node:test";

import { isChannelMember, membershipKeyboard } from "./membership.js";

test("recognizes channel members and administrators", () => {
  assert.equal(isChannelMember({ status: "creator" }), true);
  assert.equal(isChannelMember({ status: "administrator" }), true);
  assert.equal(isChannelMember({ status: "member" }), true);
  assert.equal(isChannelMember({ status: "restricted", is_member: true }), true);
});

test("requires joining when a user left, was kicked, or is not a member", () => {
  assert.equal(isChannelMember({ status: "left" }), false);
  assert.equal(isChannelMember({ status: "kicked" }), false);
  assert.equal(isChannelMember({ status: "restricted", is_member: false }), false);
  assert.equal(isChannelMember(null), false);
});

test("membership keyboard provides channel join and recheck actions", () => {
  assert.deepEqual(membershipKeyboard("https://t.me/ampublik"), {
    inline_keyboard: [
      [{ text: "📢 Gabung saluran", url: "https://t.me/ampublik" }],
      [{ text: "✅ Saya sudah bergabung", callback_data: "check_membership" }],
    ],
  });
});
