const VIDEO_25_DURATIONS = [4, 5, 6, 8, 10, 12];
const VIDEO_20_FRAME_COUNTS = {
  5: 121,
  10: 241,
  15: 361,
  18: 409,
  20: 409,
};

export const VIDEO_ASPECT_RATIOS = {
  "9:16": { width: 768, height: 1152 },
  "16:9": { width: 1280, height: 720 },
  "1:1": { width: 1024, height: 1024 },
};

export function getVideoDurations(model = process.env.AGNES_VIDEO_MODEL || "agnes-video-v2.0") {
  return model.startsWith("agnes-video-2.5")
    ? VIDEO_25_DURATIONS
    : Object.keys(VIDEO_20_FRAME_COUNTS).map(Number);
}

export function buildVideoRequest({ model, prompt, duration, aspectRatio }) {
  const dimensions = VIDEO_ASPECT_RATIOS[aspectRatio];
  if (!dimensions) throw new Error("Unsupported video aspect ratio");

  const numericDuration = Number(duration);
  if (!getVideoDurations(model).includes(numericDuration)) {
    throw new Error("Unsupported video duration for the selected model");
  }

  if (model.startsWith("agnes-video-2.5")) {
    return {
      model,
      prompt,
      mode: "text",
      seconds: String(numericDuration),
      size: "720P",
      aspect_ratio: aspectRatio,
    };
  }

  return {
    model,
    prompt,
    width: dimensions.width,
    height: dimensions.height,
    num_frames: VIDEO_20_FRAME_COUNTS[numericDuration],
    frame_rate: 24,
  };
}
