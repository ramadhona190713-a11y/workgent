function formatPercent(value) {
  if (value === null || value === undefined || value === "") return "";
  const number = Number(value);
  return Number.isFinite(number) ? `${Math.round(number)}%` : "";
}

export function formatAgnesProgress(status, progress, internalProgress) {
  const reported = formatPercent(progress);
  const internal = formatPercent(internalProgress);
  if (reported && internal && reported !== internal) {
    return `Progres AGENIO: ${reported} (internal: ${internal}) · status: ${status}`;
  }
  if (reported) return `Progres AGENIO: ${reported} · status: ${status}`;
  if (internal) return `Progres internal AGENIO: ${internal} · status: ${status}`;
  return `Status AGENIO: ${status}`;
}
