import {
  createCipheriv,
  createDecipheriv,
  randomBytes,
  scryptSync,
} from "node:crypto";
import { chmodSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";

const VERSION = 1;

function deriveKey(secret, salt) {
  if (typeof secret !== "string" || secret.length < 32) {
    throw new Error("TELEGRAM_KEY_ENCRYPTION_SECRET must contain at least 32 characters");
  }
  return scryptSync(secret, salt, 32);
}

export function encryptApiKey(apiKey, secret) {
  const salt = randomBytes(16);
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", deriveKey(secret, salt), iv);
  const ciphertext = Buffer.concat([cipher.update(apiKey, "utf8"), cipher.final()]);
  return {
    version: VERSION,
    salt: salt.toString("base64"),
    iv: iv.toString("base64"),
    tag: cipher.getAuthTag().toString("base64"),
    ciphertext: ciphertext.toString("base64"),
  };
}

export function decryptApiKey(entry, secret) {
  if (!entry || entry.version !== VERSION) {
    throw new Error("Unsupported encrypted API key record");
  }
  const decipher = createDecipheriv(
    "aes-256-gcm",
    deriveKey(secret, Buffer.from(entry.salt, "base64")),
    Buffer.from(entry.iv, "base64"),
  );
  decipher.setAuthTag(Buffer.from(entry.tag, "base64"));
  return Buffer.concat([
    decipher.update(Buffer.from(entry.ciphertext, "base64")),
    decipher.final(),
  ]).toString("utf8");
}

export class TelegramKeyStore {
  constructor({ path, secret }) {
    if (!path) throw new Error("TELEGRAM_KEY_STORE_PATH is required");
    deriveKey(secret, Buffer.alloc(16));
    this.path = path;
    this.secret = secret;
    this.entries = this.#read();
  }

  get(userId) {
    const entry = this.entries[String(userId)];
    return entry ? decryptApiKey(entry, this.secret) : "";
  }

  set(userId, apiKey) {
    if (typeof apiKey !== "string") {
      throw new Error("Invalid API key");
    }
    const cleaned = apiKey.trim();
    if (!cleaned || cleaned.length > 4096 || /[\r\n]/.test(cleaned)) {
      throw new Error("Invalid API key");
    }
    this.entries[String(userId)] = encryptApiKey(cleaned, this.secret);
    this.#write();
  }

  delete(userId) {
    const id = String(userId);
    if (!(id in this.entries)) return false;
    delete this.entries[id];
    this.#write();
    return true;
  }

  #read() {
    try {
      const parsed = JSON.parse(readFileSync(this.path, "utf8"));
      if (
        !parsed ||
        parsed.version !== VERSION ||
        !parsed.users ||
        typeof parsed.users !== "object" ||
        Array.isArray(parsed.users)
      ) {
        throw new Error("Invalid Telegram key store format");
      }
      return parsed.users;
    } catch (error) {
      if (error.code === "ENOENT") return {};
      throw error;
    }
  }

  #write() {
    const parent = dirname(this.path);
    mkdirSync(parent, { recursive: true, mode: 0o700 });
    const temporaryPath = `${this.path}.${process.pid}.tmp`;
    writeFileSync(
      temporaryPath,
      JSON.stringify({ version: VERSION, users: this.entries }),
      { encoding: "utf8", mode: 0o600 },
    );
    chmodSync(temporaryPath, 0o600);
    renameSync(temporaryPath, this.path);
  }
}
