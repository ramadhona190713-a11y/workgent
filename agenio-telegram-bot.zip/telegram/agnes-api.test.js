import assert from "node:assert/strict";
import test from "node:test";

import { AgnesApi } from "./agnes-api.js";
import { buildVideoRequest, getVideoDurations } from "./video-options.js";

test("offers all Agnes v2.0 duration presets, including 10 seconds", () => {
  assert.deepEqual(getVideoDurations("agnes-video-v2.0"), [5, 10, 15, 18, 20]);
  assert.deepEqual(getVideoDurations("agnes-video-2.5-flash"), [4, 5, 6, 8, 10, 12]);
});

test("builds a 10-second landscape request with the model's exact parameters", () => {
  assert.deepEqual(
    buildVideoRequest({
      model: "agnes-video-v2.0",
      prompt: "A landscape",
      duration: 10,
      aspectRatio: "16:9",
    }),
    {
      model: "agnes-video-v2.0",
      prompt: "A landscape",
      width: 1280,
      height: 720,
      num_frames: 241,
      frame_rate: 24,
    },
  );
  assert.deepEqual(
    buildVideoRequest({
      model: "agnes-video-2.5-flash",
      prompt: "A portrait",
      duration: 10,
      aspectRatio: "9:16",
    }),
    {
      model: "agnes-video-2.5-flash",
      prompt: "A portrait",
      mode: "text",
      seconds: "10",
      size: "720P",
      aspect_ratio: "9:16",
    },
  );
});

test("creative task prompt rewrite uses the caller's API key and returns text", async () => {
  const originalFetch = globalThis.fetch;
  let request;
  globalThis.fetch = async (url, options) => {
    request = { url: String(url), options };
    return new Response(JSON.stringify({
      choices: [{ message: { content: "A cinematic scene" } }],
    }), { status: 200 });
  };
  try {
    const api = new AgnesApi({ apiKey: "per-user-key" });
    assert.equal(await api.rewritePrompt("creative", "A story"), "A cinematic scene");
    assert.equal(request.url, "https://apihub.agnes-ai.com/v1/chat/completions");
    assert.equal(request.options.headers.Authorization, "Bearer per-user-key");
    assert.equal(JSON.parse(request.options.body).messages[1].content, "A story");
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("image generation rejects successful responses without an image", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(JSON.stringify({ data: [] }), { status: 200 });
  try {
    const api = new AgnesApi({ apiKey: "per-user-key" });
    await assert.rejects(api.generateImage("A landscape"), /no image/);
  } finally {
    globalThis.fetch = originalFetch;
  }
});
