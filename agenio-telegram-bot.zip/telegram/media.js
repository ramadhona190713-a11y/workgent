const MAX_TELEGRAM_VIDEO_BYTES = 49_000_000;
const REDIRECT_STATUSES = new Set([301, 302, 303, 307, 308]);

function isTrustedAgnesMediaUrl(value) {
  let url;
  try {
    url = new URL(value);
  } catch {
    return false;
  }
  if (url.protocol !== "https:") return false;
  const host = url.hostname.toLowerCase();
  return (
    host === "agnes-ai.space" ||
    host.endsWith(".agnes-ai.space") ||
    host === "agnes-ai.cn" ||
    host.endsWith(".agnes-ai.cn")
  );
}

export class VideoTooLargeError extends Error {
  constructor() {
    super("Telegram's video upload limit was exceeded");
    this.name = "VideoTooLargeError";
  }
}

export async function downloadAgnesVideo(videoUrl) {
  let currentUrl = videoUrl;
  let response;

  for (let redirectCount = 0; redirectCount <= 3; redirectCount += 1) {
    if (!isTrustedAgnesMediaUrl(currentUrl)) {
      throw new Error("Agnes returned an unsupported video download URL");
    }
    response = await fetch(currentUrl, {
      redirect: "manual",
      signal: AbortSignal.timeout(180_000),
    });
    if (!REDIRECT_STATUSES.has(response.status)) break;
    const location = response.headers.get("location");
    if (!location || redirectCount === 3) {
      throw new Error("Agnes video download redirected too many times");
    }
    currentUrl = new URL(location, currentUrl).toString();
  }

  if (!response?.ok || !response.body) {
    throw new Error(`Agnes video download failed (HTTP ${response?.status || "unknown"})`);
  }

  const contentLength = Number(response.headers.get("content-length"));
  if (Number.isFinite(contentLength) && contentLength > MAX_TELEGRAM_VIDEO_BYTES) {
    await response.body.cancel();
    throw new VideoTooLargeError();
  }

  const reader = response.body.getReader();
  const chunks = [];
  let totalBytes = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      totalBytes += value.byteLength;
      if (totalBytes > MAX_TELEGRAM_VIDEO_BYTES) {
        await reader.cancel();
        throw new VideoTooLargeError();
      }
      chunks.push(Buffer.from(value));
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks, totalBytes);
}
