import assert from "node:assert/strict";
import test from "node:test";

import { formatAgnesProgress } from "./progress.js";

test("shows the progress value reported by Agnes without estimating", () => {
  assert.equal(
    formatAgnesProgress("in_progress", 37, 37),
    "Progres AGENIO: 37% · status: in_progress",
  );
  assert.equal(
    formatAgnesProgress("in_progress", 0, 100),
    "Progres AGENIO: 0% (internal: 100%) · status: in_progress",
  );
});

test("falls back to upstream status when Agnes omits numeric progress", () => {
  assert.equal(formatAgnesProgress("pending", null, undefined), "Status AGENIO: pending");
});
