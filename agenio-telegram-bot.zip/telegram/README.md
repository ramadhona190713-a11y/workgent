# AGENIO Telegram Bot (Node.js)

This standalone Telegram bot runs with `npm start`. It calls the configured AI provider directly and does not
start or import the Python/Web application. The existing Web application remains available via
`npm run start:web`.

## Setup

1. Create a Telegram bot with BotFather and get its token. If a token was shared in chat, revoke
   it with BotFather first and use a fresh token.
2. Add the bot to `@ampublik` as a channel administrator so it can verify membership.
3. Copy `telegram/.env.example` to `telegram/.env` and set `TELEGRAM_BOT_TOKEN`.
4. Set `TELEGRAM_KEY_ENCRYPTION_SECRET` to a randomly generated secret of at least 32 characters.
   Keep it safe: changing or losing it makes previously stored user keys unreadable.
5. From the repository root, run `npm start`. If using the standalone ZIP, enter the extracted
   `telegram/` folder first, then run `npm start`.

The bot reads `.env` beside `bot.js`. In the full repository this is `telegram/.env`; in the
standalone ZIP, copy `.env.example` to `.env` inside the extracted folder. Local `.env` files
are ignored by Git in the full repository.

The bot only accepts private chats. Each Telegram account stores its own API key encrypted
with AES-256-GCM under `.agnes_config/telegram-api-keys.json` (or
`TELEGRAM_KEY_STORE_PATH`). The key is never used as a shared application key. Users can add a
key from the **Atur API Key** button; **Dapatkan API Key** opens the provider's key page. The bot
attempts to delete the message containing a submitted key, but users should delete it manually if
Telegram disallows deletion.

Every command and button requires membership in `@ampublik`. The bot checks membership before
processing each update and offers a join button plus a membership recheck. Keep the bot as an
administrator of that channel; if Telegram rejects the check, the bot fails closed. Use BotFather
to change the bot's Telegram display name to **AGENIO**.

## Bot behavior

The menu offers simple video, creative idea, manuscript, presenter script, poetry, and image.
Video jobs use the configured video API; creative/manuscript/presenter/poetry prompts are first
refined using the configured chat API. The standalone bot creates one video clip for each request. It does not reproduce the
Web application's multi-scene stitching, TTS narration, subtitle rendering, or intermediate
artifact management. While polling, the bot edits one Telegram message to show the upstream-reported
`progress` percentage and status; if the provider also reports a different `internal_progress`, both
upstream values are shown rather than estimating or conflating them.
Before a video prompt is entered, users choose one of the durations supported by the configured
video model and a portrait (9:16), landscape (16:9), or square (1:1) aspect ratio. The v2.0
duration options are 5, 10, 15, 18, and 20 seconds; 2.5 models offer 4, 5, 6, 8, 10,
and 12 seconds.
Completed video files are downloaded from the provider and uploaded to Telegram directly. Videos
over the bot's conservative 49 MB upload cap are returned as a download link instead.

The default model is `agnes-video-v2.0`. The upstream `agnes-video-2.5-flash` model has a known
sideways-content issue for portrait `9:16` output; choose another aspect ratio or model if that
behavior matters.

Environment options:

| Variable | Default | Purpose |
| --- | --- | --- |
| `TELEGRAM_BOT_TOKEN` | — | Telegram Bot API token |
| `TELEGRAM_KEY_ENCRYPTION_SECRET` | — | Encryption secret for stored per-user API keys |
| `TELEGRAM_KEY_STORE_PATH` | `.agnes_config/telegram-api-keys.json` | Encrypted key-store location |
| `AGENIO_REQUIRED_CHANNEL` | `@ampublik` | Required Telegram channel |
| `AGNES_API_DOMAIN` | `com` | Provider API site: `com`, `cn`, or `cn_bak` |
| `AGNES_TEXT_MODEL` | `agnes-3.0-flash` | Model used to refine long-form prompts |
| `AGNES_IMAGE_MODEL` | `agnes-image-2.5-flash` | Image generation model |
| `AGNES_VIDEO_MODEL` | `agnes-video-v2.0` | Video generation model |
| `AGNES_VIDEO_POLL_TIMEOUT` | `1800` | Maximum video polling time in seconds |
| `AGNES_VIDEO_QUEUE_RETRY_SECONDS` | `900` | Retry budget for a full upstream video queue |

Run unit tests with `npm run test:telegram`.
