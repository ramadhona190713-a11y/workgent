import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { AgnesApi } from "./agnes-api.js";
import { loadDotEnv } from "./env.js";
import { TelegramKeyStore } from "./key-store.js";
import { downloadAgnesVideo, VideoTooLargeError } from "./media.js";
import { formatAgnesProgress } from "./progress.js";
import { getVideoDurations, VIDEO_ASPECT_RATIOS } from "./video-options.js";
import { isChannelMember, membershipKeyboard } from "./membership.js";

const botDir = dirname(fileURLToPath(import.meta.url));
loadDotEnv(resolve(botDir, ".env"));

const botToken = process.env.TELEGRAM_BOT_TOKEN;
const keySecret = process.env.TELEGRAM_KEY_ENCRYPTION_SECRET;
const keyStorePath = resolve(
  process.env.TELEGRAM_KEY_STORE_PATH ||
    resolve(botDir, "../.agnes_config/telegram-api-keys.json"),
);
const requiredChannel = process.env.AGENIO_REQUIRED_CHANNEL || "@ampublik";
const requiredChannelUrl = `https://t.me/${requiredChannel.replace(/^@/, "")}`;
const apiRoot = `https://api.telegram.org/bot${botToken}`;
const flows = new Map();
const activeJobs = new Set();
let keyStore;

const taskTypes = {
  video: { label: "Video sederhana", input: "prompt" },
  creative: { label: "Video kreatif", input: "idea" },
  manuscript: { label: "Video dari naskah", input: "naskah" },
  anchor: { label: "Video presenter", input: "naskah presenter" },
  poetry: { label: "Video puisi", input: "puisi" },
  image: { label: "Gambar", input: "prompt gambar" },
};

const mainKeyboard = {
  inline_keyboard: [
    [
      { text: "🎬 Buat video/gambar", callback_data: "generate" },
      { text: "🔑 Atur API Key", callback_data: "set_key" },
    ],
    [
      { text: "Dapatkan API Key", url: "https://platform.agnes-ai.com" },
      { text: "Hapus API Key", callback_data: "delete_key" },
    ],
  ],
};

async function telegram(method, payload = {}) {
  const isMultipart = payload instanceof FormData;
  const response = await fetch(`${apiRoot}/${method}`, {
    method: "POST",
    headers: isMultipart ? undefined : { "Content-Type": "application/json" },
    body: isMultipart ? payload : JSON.stringify(payload),
    signal: AbortSignal.timeout(60_000),
  });
  let result;
  try {
    result = await response.json();
  } catch {
    throw new Error(`Telegram ${method} returned an invalid response (HTTP ${response.status})`);
  }
  if (!response.ok || !result.ok) {
    const description = String(result.description || "request rejected").slice(0, 250);
    throw new Error(`Telegram ${method} failed (HTTP ${response.status}): ${description}`);
  }
  return result.result;
}

async function reply(chatId, text, extra = {}) {
  return telegram("sendMessage", { chat_id: chatId, text, ...extra });
}

function isPrivate(update) {
  return update.message?.chat?.type === "private" ||
    update.callback_query?.message?.chat?.type === "private";
}

async function showMenu(chatId) {
  const hasKey = Boolean(keyStore.get(chatId));
  const keyStatus = hasKey ? "API Key Anda sudah tersimpan dengan aman." :
    "Tambahkan API Key Anda untuk mulai.";
  await reply(chatId, `${keyStatus}\nPilih tindakan:`, {
    reply_markup: mainKeyboard,
  });
}

async function requireChannelMembership(chatId, userId) {
  let member;
  try {
    member = await telegram("getChatMember", {
      chat_id: requiredChannel,
      user_id: userId,
    });
  } catch (error) {
    console.error(`[AGENIO] Membership check failed for configured channel: ${error.message}`);
    await reply(
      chatId,
      "AGENIO belum dapat memverifikasi keanggotaan. Admin bot perlu memastikan bot menjadi admin di saluran @ampublik.",
    );
    return false;
  }

  if (isChannelMember(member)) return true;
  await reply(
    chatId,
    "Untuk menggunakan AGENIO, bergabunglah terlebih dahulu ke saluran wajib kami, lalu tekan tombol verifikasi.",
    { reply_markup: membershipKeyboard(requiredChannelUrl) },
  );
  return false;
}

async function startGenerate(chatId) {
  const buttons = Object.entries(taskTypes).map(([id, task]) => ([
    { text: task.label, callback_data: `type:${id}` },
  ]));
  await reply(chatId, "Pilih jenis tugas:", {
    reply_markup: { inline_keyboard: buttons },
  });
}

async function askVideoDuration(chatId, type) {
  const model = process.env.AGNES_VIDEO_MODEL || "agnes-video-v2.0";
  const durations = getVideoDurations(model);
  const buttons = [];
  for (let index = 0; index < durations.length; index += 3) {
    buttons.push(
      durations.slice(index, index + 3).map((seconds) => ({
        text: `${seconds} detik`,
        callback_data: `duration:${seconds}`,
      })),
    );
  }
  flows.set(chatId, { step: "duration", type });
  await reply(chatId, "Pilih durasi video:", {
    reply_markup: { inline_keyboard: buttons },
  });
}

async function askVideoAspectRatio(chatId, type, duration) {
  flows.set(chatId, { step: "aspect_ratio", type, duration });
  await reply(chatId, "Pilih orientasi/rasio video:", {
    reply_markup: {
      inline_keyboard: [[
        { text: "Vertikal 9:16", callback_data: "ratio:9:16" },
        { text: "Horizontal 16:9", callback_data: "ratio:16:9" },
        { text: "Persegi 1:1", callback_data: "ratio:1:1" },
      ]],
    },
  });
}

async function answerCallback(callbackId, text) {
  try {
    await telegram("answerCallbackQuery", {
      callback_query_id: callbackId,
      text,
      show_alert: false,
    });
  } catch {
    // A stale callback should not stop the polling loop.
  }
}

async function createImage(chatId, api, prompt) {
  await reply(chatId, "Sedang membuat gambar. Mohon tunggu…");
  const result = await api.generateImage(prompt);
  if (result.url) {
    await telegram("sendPhoto", {
      chat_id: chatId,
      photo: result.url,
      caption: "Gambar selesai dibuat.",
    });
    return;
  }
  const bytes = Buffer.from(result.base64, "base64");
  const form = new FormData();
  form.set("chat_id", String(chatId));
  form.set("caption", "Gambar selesai dibuat.");
  form.set("photo", new Blob([bytes], { type: "image/png" }), "image.png");
  const response = await fetch(`${apiRoot}/sendPhoto`, {
    method: "POST",
    body: form,
    signal: AbortSignal.timeout(60_000),
  });
  const payload = await response.json();
  if (!response.ok || !payload.ok) throw new Error("Telegram could not deliver the generated image");
}

async function createVideo(chatId, api, type, text, options) {
  let prompt = text;
  if (["creative", "manuscript", "anchor", "poetry"].includes(type)) {
    await reply(chatId, "AGENIO sedang menyiapkan prompt…");
    prompt = await api.rewritePrompt(type, text);
  }
  const progressMessage = await reply(
    chatId,
    "AGENIO sedang memproses video. Menunggu progres…",
  );
  let lastStatus = "";
  let lastProgressText = "";
  const videoUrl = await api.generateVideo(prompt, {
    ...options,
    onProgress: async (status, progress, internalProgress) => {
    const progressText = formatAgnesProgress(status, progress, internalProgress);
    if (progressText !== lastProgressText || status !== lastStatus) {
      lastStatus = status;
      lastProgressText = progressText;
      try {
        await telegram("editMessageText", {
          chat_id: chatId,
          message_id: progressMessage.message_id,
          text: progressText,
        });
      } catch (error) {
        console.error(`[TelegramBot] Progress update failed: ${error.message}`);
      }
    }
    },
  });
  try {
    await telegram("editMessageText", {
      chat_id: chatId,
      message_id: progressMessage.message_id,
      text: "AGENIO selesai memproses; sedang mengirim video…",
    });
  } catch (error) {
    console.error(`[TelegramBot] Completion status update failed: ${error.message}`);
  }
  try {
    const video = await downloadAgnesVideo(videoUrl);
    const form = new FormData();
    form.set("chat_id", String(chatId));
    form.set("caption", "Video selesai dibuat.");
    form.set("supports_streaming", "true");
    form.set("video", new Blob([video], { type: "video/mp4" }), "agnes-video.mp4");
    await telegram("sendVideo", form);
  } catch (error) {
    if (error instanceof VideoTooLargeError) {
      await reply(
        chatId,
        `Video selesai dibuat, tetapi ukurannya melebihi batas unggah Telegram (49 MB). Unduh melalui tautan ini:\n${videoUrl}`,
      );
      return;
    }
    throw new Error(
      `Video sudah dibuat, tetapi gagal dikirim ke Telegram: ${error.message}. Tautan unduh:\n${videoUrl}`,
    );
  }
}

async function handleText(message) {
  const chatId = message.chat.id;
  if (message.chat.type !== "private") {
    await reply(chatId, "Silakan gunakan bot ini lewat chat pribadi.");
    return;
  }
  const text = (message.text || "").trim();
  if (!text) return;
  if (text === "/start" || text === "/menu") {
    flows.delete(chatId);
    await showMenu(chatId);
    return;
  }
  if (text === "/cancel") {
    flows.delete(chatId);
    await reply(chatId, "Dibatalkan.");
    return;
  }
  if (text === "/deletekey") {
    const removed = keyStore.delete(chatId);
    flows.delete(chatId);
    await reply(chatId, removed ? "API Key akun ini sudah dihapus." : "Belum ada API Key tersimpan.");
    return;
  }
  if (text === "/setkey") {
    flows.set(chatId, { step: "api_key" });
    await reply(chatId, "Kirim API Key Anda di chat pribadi ini. /cancel untuk batal.");
    return;
  }
  if (text === "/generate") {
    await startGenerate(chatId);
    return;
  }

  const flow = flows.get(chatId);
  if (!flow) {
    await showMenu(chatId);
    return;
  }
  if (flow.step === "api_key") {
    try {
      keyStore.set(chatId, text);
      flows.delete(chatId);
      try {
        await telegram("deleteMessage", { chat_id: chatId, message_id: message.message_id });
      } catch {
        await reply(chatId, "Catatan: Telegram tidak mengizinkan bot menghapus pesan API Key. Hapus pesan tersebut secara manual.");
      }
      await reply(chatId, "API Key sudah tersimpan terenkripsi khusus untuk akun Telegram Anda.");
    } catch (error) {
      await reply(chatId, error.message);
    }
    return;
  }

  if (flow.step === "prompt") {
    flows.delete(chatId);
    const apiKey = keyStore.get(chatId);
    if (!apiKey) {
      await reply(chatId, "API Key belum diatur. Gunakan tombol Atur API Key terlebih dahulu.");
      return;
    }
    const task = taskTypes[flow.type];
    if (activeJobs.has(chatId)) {
      await reply(chatId, "Tugas Anda sebelumnya masih berjalan. Tunggu hingga selesai sebelum memulai tugas lain.");
      return;
    }
    if (activeJobs.size >= 3) {
      await reply(chatId, "Bot sedang menangani beberapa tugas. Coba lagi sebentar.");
      return;
    }
    activeJobs.add(chatId);
    try {
      const api = new AgnesApi({
        apiKey,
        domain: process.env.AGNES_API_DOMAIN || "com",
      });
      if (flow.type === "image") {
        await createImage(chatId, api, text);
      } else {
        await createVideo(chatId, api, flow.type, text, {
          duration: flow.duration,
          aspectRatio: flow.aspectRatio,
        });
      }
    } catch (error) {
      const safeMessage = error.message
        .replaceAll(apiKey, "[redacted]")
        .replaceAll(botToken, "[redacted]")
        .replace(/agnes/gi, "AGENIO")
        .slice(0, 1000);
      console.error(`[AGENIO] ${task.label} failed: ${safeMessage}`);
      await reply(chatId, `Gagal membuat ${task.label.toLowerCase()}: ${safeMessage}`);
    } finally {
      activeJobs.delete(chatId);
    }
  }
}

async function handleCallback(callback) {
  const chatId = callback.message.chat.id;
  const data = callback.data || "";
  if (data === "check_membership") {
    await showMenu(chatId);
  } else if (data === "generate") {
    await startGenerate(chatId);
  } else if (data === "set_key") {
    flows.set(chatId, { step: "api_key" });
    await reply(
      chatId,
      "Kirim API Key Anda di chat pribadi ini. Pesan key akan dihapus setelah disimpan jika Telegram mengizinkan. Gunakan /cancel untuk batal.",
    );
  } else if (data === "delete_key") {
    const removed = keyStore.delete(chatId);
    await reply(chatId, removed ? "API Key sudah dihapus." : "Belum ada API Key tersimpan.");
  } else if (data.startsWith("type:")) {
    const type = data.slice(5);
    const task = taskTypes[type];
    if (!task) {
      await reply(chatId, "Jenis tugas tidak dikenal.");
      return;
    }
    if (!keyStore.get(chatId)) {
      await reply(chatId, "Atur API Key terlebih dahulu.", {
        reply_markup: mainKeyboard,
      });
      return;
    }
    if (type === "image") {
      flows.set(chatId, { step: "prompt", type });
      await reply(chatId, `Kirim ${task.input} Anda. /cancel untuk batal.`);
    } else {
      await askVideoDuration(chatId, type);
    }
  } else if (data.startsWith("duration:")) {
    const flow = flows.get(chatId);
    const duration = Number(data.slice("duration:".length));
    if (flow?.step !== "duration" || !getVideoDurations().includes(duration)) {
      await reply(chatId, "Pilihan durasi tidak valid. Mulai lagi dengan /generate.");
      return;
    }
    await askVideoAspectRatio(chatId, flow.type, duration);
  } else if (data.startsWith("ratio:")) {
    const flow = flows.get(chatId);
    const aspectRatio = data.slice("ratio:".length);
    if (flow?.step !== "aspect_ratio" || !(aspectRatio in VIDEO_ASPECT_RATIOS)) {
      await reply(chatId, "Pilihan rasio tidak valid. Mulai lagi dengan /generate.");
      return;
    }
    const task = taskTypes[flow.type];
    flows.set(chatId, {
      step: "prompt",
      type: flow.type,
      duration: flow.duration,
      aspectRatio,
    });
    await reply(
      chatId,
      `Pilihan: ${flow.duration} detik, ${aspectRatio}. Kirim ${task.input} Anda. /cancel untuk batal.`,
    );
  }
}

async function handleUpdate(update) {
  if (!isPrivate(update)) return;
  if (update.callback_query) {
    await answerCallback(update.callback_query.id, "Memeriksa keanggotaan…");
  }
  const chatId = update.message?.chat.id || update.callback_query?.message?.chat.id;
  const userId = update.message?.from.id || update.callback_query?.from.id;
  if (!chatId || !userId || !(await requireChannelMembership(chatId, userId))) {
    return;
  }
  if (update.callback_query) {
    await handleCallback(update.callback_query);
  } else if (update.message) {
    await handleText(update.message);
  }
}

async function run() {
  if (!botToken || !/^\d+:[A-Za-z0-9_-]{30,}$/.test(botToken)) {
    throw new Error("Set a fresh valid TELEGRAM_BOT_TOKEN in telegram/.env");
  }
  if (!keySecret || keySecret.length < 32 || keySecret.startsWith("REPLACE_WITH_")) {
    throw new Error("Set your own random TELEGRAM_KEY_ENCRYPTION_SECRET in telegram/.env");
  }
  keyStore = new TelegramKeyStore({ path: keyStorePath, secret: keySecret });
  const me = await telegram("getMe");
  const botMembership = await telegram("getChatMember", {
    chat_id: requiredChannel,
    user_id: me.id,
  });
  if (!["creator", "administrator"].includes(botMembership.status)) {
    throw new Error(`Add @${me.username} as an administrator of ${requiredChannel}`);
  }
  await telegram("setMyName", { name: "AGENIO" });
  console.info(`[AGENIO] Started as @${me.username}; required channel ${requiredChannel}; key store: ${keyStorePath}`);
  let offset = 0;
  while (true) {
    try {
      const updates = await telegram("getUpdates", {
        offset,
        timeout: 45,
        allowed_updates: ["message", "callback_query"],
      });
      for (const update of updates) {
        offset = update.update_id + 1;
        void handleUpdate(update).catch((error) => {
          console.error(`[AGENIO] Update failed: ${error.message.replace(/agnes/gi, "AGENIO")}`);
        });
      }
    } catch (error) {
      console.error(`[AGENIO] Polling failed: ${error.message.replace(/agnes/gi, "AGENIO")}`);
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }
}

run().catch((error) => {
  console.error(`[AGENIO] Startup failed: ${error.message.replace(/agnes/gi, "AGENIO")}`);
  process.exitCode = 1;
});
