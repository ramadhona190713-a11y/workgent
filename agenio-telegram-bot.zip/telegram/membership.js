const ALLOWED_MEMBER_STATUSES = new Set(["creator", "administrator", "member"]);

export function isChannelMember(chatMember) {
  if (!chatMember || typeof chatMember.status !== "string") return false;
  if (ALLOWED_MEMBER_STATUSES.has(chatMember.status)) return true;
  return chatMember.status === "restricted" && chatMember.is_member === true;
}

export function membershipKeyboard(channelUrl) {
  return {
    inline_keyboard: [
      [{ text: "📢 Gabung saluran", url: channelUrl }],
      [{ text: "✅ Saya sudah bergabung", callback_data: "check_membership" }],
    ],
  };
}
