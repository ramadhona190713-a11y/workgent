import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

import { decryptApiKey, encryptApiKey, TelegramKeyStore } from "./key-store.js";

test("encrypted key store isolates users and never writes API keys in plaintext", () => {
  const directory = mkdtempSync(join(tmpdir(), "agnes-telegram-"));
  try {
    const path = join(directory, "keys.json");
    const secret = "test-encryption-secret-that-is-long-enough";
    const store = new TelegramKeyStore({ path, secret });
    store.set(101, "agnes-key-one");
    store.set(202, "agnes-key-two");

    assert.equal(store.get(101), "agnes-key-one");
    assert.equal(store.get(202), "agnes-key-two");
    assert.equal(store.get(303), "");
    const persisted = readFileSync(path, "utf8");
    assert.equal(persisted.includes("agnes-key-one"), false);
    assert.equal(persisted.includes("agnes-key-two"), false);

    assert.equal(store.delete(101), true);
    assert.equal(store.get(101), "");
    assert.equal(store.delete(101), false);
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});

test("encrypted records reject a wrong secret or tampered ciphertext", () => {
  const entry = encryptApiKey("sample-key", "correct-secret-long-enough-123456");
  assert.throws(() =>
    decryptApiKey(entry, "different-secret-long-enough-123456"),
  );
  assert.throws(() =>
    decryptApiKey({ ...entry, ciphertext: Buffer.from("tampered").toString("base64") },
      "correct-secret-long-enough-123456"),
  );
});
