import assert from "node:assert/strict";
import test from "node:test";

import { downloadAgnesVideo, VideoTooLargeError } from "./media.js";

test("downloads Agnes media from an approved HTTPS host", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(new Uint8Array([1, 2, 3]), {
    status: 200,
    headers: { "content-type": "video/mp4" },
  });
  try {
    assert.deepEqual(
      await downloadAgnesVideo("https://platform-outputs.agnes-ai.space/video.mp4"),
      Buffer.from([1, 2, 3]),
    );
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("rejects unsupported media URLs before making a request", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => {
    throw new Error("fetch should not be called");
  };
  try {
    await assert.rejects(
      downloadAgnesVideo("http://127.0.0.1/internal"),
      /unsupported video download URL/,
    );
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("uses an Agnes download link instead of exceeding Telegram's upload cap", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response("x", {
    status: 200,
    headers: { "content-length": "49000001" },
  });
  try {
    await assert.rejects(
      downloadAgnesVideo("https://platform-outputs.agnes-ai.space/large.mp4"),
      VideoTooLargeError,
    );
  } finally {
    globalThis.fetch = originalFetch;
  }
});
