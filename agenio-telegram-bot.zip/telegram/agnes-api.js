import { buildVideoRequest } from "./video-options.js";

const DOMAINS = {
  com: "https://apihub.agnes-ai.com",
  cn: "https://api.agnes-ai.cn",
  cn_bak: "https://apihub.agnes-ai.cn",
};

export class AgnesApi {
  constructor({ apiKey, domain = "com" }) {
    if (!apiKey) throw new Error("API key is not configured");
    if (!(domain in DOMAINS)) throw new Error("AGNES_API_DOMAIN must be com, cn, or cn_bak");
    this.apiKey = apiKey;
    this.root = DOMAINS[domain];
    this.base = `${this.root}/v1`;
  }

  async #request(url, options = {}) {
    const { timeout = 180_000, ...requestOptions } = options;
    const response = await fetch(url, {
      ...requestOptions,
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        ...(requestOptions.headers || {}),
      },
      signal: AbortSignal.timeout(timeout),
    });
    const body = await response.text();
    let data;
    try {
      data = body ? JSON.parse(body) : {};
    } catch {
      data = {};
    }
    if (!response.ok) {
      const message = data?.error?.message || data?.message || `HTTP ${response.status}`;
      const error = new Error(`Agnes API error: ${String(message).slice(0, 250)}`);
      error.status = response.status;
      error.code = data?.error?.code || data?.code || "";
      throw error;
    }
    return data;
  }

  async #requestWithRetry(url, options, attempts = 4) {
    for (let attempt = 0; ; attempt += 1) {
      try {
        return await this.#request(url, options);
      } catch (error) {
        const retryable =
          [429, 500, 502, 503, 504].includes(error.status) ||
          ["TimeoutError", "TypeError"].includes(error.name);
        if (!retryable || attempt >= attempts - 1) {
          throw error;
        }
        await new Promise((resolve) => setTimeout(resolve, 20_000 * (attempt + 1)));
      }
    }
  }

  async rewritePrompt(taskType, text) {
    const instructions = {
      creative: "Turn this video idea into one concise cinematic text-to-video prompt. Output only the prompt.",
      manuscript: "Turn this manuscript excerpt into one visual text-to-video prompt. Do not quote or summarize the manuscript. Output only the prompt.",
      anchor: "Turn this speaking script into a visual text-to-video prompt for a presenter. Output only the prompt.",
      poetry: "Turn this poem into one cinematic visual text-to-video prompt. Output only the prompt.",
    };
    const data = await this.#requestWithRetry(`${this.base}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.AGNES_TEXT_MODEL || "agnes-3.0-flash",
        messages: [
          { role: "system", content: instructions[taskType] },
          { role: "user", content: text },
        ],
        temperature: 0.7,
        max_tokens: 600,
      }),
      timeout: 300_000,
    });
    const prompt = data?.choices?.[0]?.message?.content?.trim();
    if (!prompt) throw new Error("Agnes Chat returned an empty prompt");
    return prompt;
  }

  async generateImage(prompt) {
    const data = await this.#requestWithRetry(`${this.base}/images/generations`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.AGNES_IMAGE_MODEL || "agnes-image-2.5-flash",
        prompt,
        size: "1024x1024",
        n: 1,
      }),
      timeout: 300_000,
    });
    const result = data?.data?.[0];
    if (result?.url) return { url: result.url };
    if (result?.b64_json) return { base64: result.b64_json };
    throw new Error("Agnes Image returned no image");
  }

  async generateVideo(prompt, { duration, aspectRatio, onProgress }) {
    const videoModel = process.env.AGNES_VIDEO_MODEL || "agnes-video-v2.0";
    const is25 = videoModel.startsWith("agnes-video-2.5");
    const videoRequest = buildVideoRequest({
      model: videoModel,
      prompt,
      duration,
      aspectRatio,
    });
    const submit = await this.#submitVideo(videoRequest);
    const videoId = submit.video_id || submit.task_id || submit.id;
    if (!videoId) throw new Error("Agnes Video did not return a task ID");

    const deadline = Date.now() + Number(process.env.AGNES_VIDEO_POLL_TIMEOUT || 1800) * 1000;
    let polls = 0;
    while (Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 20_000));
      const url = new URL(`${this.root}/agnesapi`);
      url.searchParams.set("video_id", videoId);
      if (is25) {
        url.searchParams.set("model_name", videoModel);
      }
      try {
        const result = await this.#request(url, { method: "GET", timeout: 30_000 });
        polls += 1;
        await onProgress?.(
          result.status || "processing",
          result.progress,
          result.internal_progress,
        );
        if (["completed", "COMPLETED"].includes(result.status)) {
          const videoUrl =
            result.remixed_from_video_id || result.video_url || result.url ||
            result.data?.video_url || result.data?.url;
          if (!videoUrl) throw new Error("Completed video has no download URL");
          return videoUrl;
        }
        if (["failed", "FAILED"].includes(result.status)) {
          const message = result.error?.message || result.error || "Video generation failed";
          throw new Error(String(message).slice(0, 250));
        }
      } catch (error) {
        if (error.status !== 404) throw error;
        polls += 1;
      }
      if (polls && polls % 10 === 0) onProgress?.("processing", undefined);
    }
    throw new Error("Video generation timed out");
  }

  async #submitVideo(videoRequest) {
    const queueBudget = Number(process.env.AGNES_VIDEO_QUEUE_RETRY_SECONDS || 900) * 1000;
    const queueStarted = Date.now();
    let attempt = 0;
    while (true) {
      try {
        return await this.#request(`${this.base}/videos`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(videoRequest),
        });
      } catch (error) {
        const queueFull = error.status === 503 &&
          ["video_queue_full", "fail_to_fetch_task"].includes(error.code);
        if (queueFull && Date.now() - queueStarted < queueBudget) {
          const delay = 30_000 + Math.floor(Math.random() * 30_000);
          await new Promise((resolve) => setTimeout(resolve, delay));
          continue;
        }
        const retryable =
          [429, 500, 502, 503, 504].includes(error.status) ||
          ["TimeoutError", "TypeError"].includes(error.name);
        if (retryable && attempt < 4) {
          attempt += 1;
          await new Promise((resolve) => setTimeout(resolve, 30_000 * attempt));
          continue;
        }
        throw error;
      }
    }
  }
}
